class UnionFindOpt:
    def __init__(self, N):
        self.N = N
        self.parents = []
        self.weights = [1]*N
        self._calls = 0
        self._operations = 0
        #self.weights = [1]*N
        for i in range(N):
            self.parents.append(i)

    def root(self,i):
        self._operations += 1
        if self.parents[i] != i:
            self.parents[i] = self.root(self.parents[i])
            
        return self.parents[i]    
    
    def find(self, i, j):
        self._calls += 1
        return self.root(i) == self.root(j)    
    
    def union(self, i, j):
        self._operations += 1
        self._calls += 1
        root_i = self.root(i)
        root_j = self.root(j)

        if root_i != root_j:
            if self.weights[root_i] > self.weights[root_j]:
                self.parents[root_j] = root_i
                self.weights[root_i] += self.weights[root_j]
            else:
                self.parents[root_i] = root_j
                self.weights[root_j] += self.weights[root_i]
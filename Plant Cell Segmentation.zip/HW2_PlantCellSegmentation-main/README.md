# HW2_PlantCellSegmentation

Plant cell image taken from <a href = "https://www.flickr.com/photos/146824358@N03/35486476174">https://www.flickr.com/photos/146824358@N03/35486476174</a>, a public domain creative commons source
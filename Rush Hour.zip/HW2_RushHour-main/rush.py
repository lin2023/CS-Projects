from heapq import heappush, heappop

class Car:
    def __init__(self, i, j, L, horiz):
        """
        Parameters
        i: int
            Row of the car
        j: int
            Column of the car
        L: int
            Length of the car
        horiz: boolean
            True if the car is horizontal, false
            if the car is vertical
        """
        self.i = i
        self.j = j
        self.L = L
        self.horiz = horiz

class State:
    def __init__(self):
        self.N = 0 # Our cars are on an NxN grid
        self.cars = [] # The first car is the red car
        self.goal = [0, 0] # The state that our red car needs to reach
        self.prev = None # Pointers to previous states (use later)

    def clone(self):
        """
        Make a deep copy of this state

        Return
        ------
        State: Deep copy of this state
        """
        s = State()
        s.N = self.N
        for c in self.cars:
            s.cars.append(Car(c.i, c.j, c.L, c.horiz))
        s.goal = self.goal.copy()
        return s

    def load_puzzle(self, filename):
        """
        Load in a puzzle from a text file
        
        Parameters
        ----------
        filename: string
            Path to puzzle
        """
        fin = open(filename)
        lines = fin.readlines()
        fin.close()
        self.N = int(lines[0])
        self.goal = [int(k) for k in lines[1].split()]
        for line in lines[2::]:
            fields = line.rstrip().split()
            i, j, L = int(fields[0]), int(fields[1]), int(fields[3])
            horiz = True
            if "v" in fields[2]:
                horiz = False
            self.cars.append(Car(i, j, L, horiz))

    def get_state_grid(self):
        """
        Return an NxN 2D list corresponding to this state.  Each
        element has a number corresponding to the car that occupies 
        that cell, or is a -1 if the cell is empty

        Returns
        -------
        list of list: The grid of numbers for the state
        """
        grid = [[-1]*self.N for i in range(self.N)]
        for idx, c in enumerate(self.cars):
            di = 0
            dj = 0
            if c.horiz:
                dj = 1
            else:
                di = 1
            i, j = c.i, c.j
            for k in range(c.L):
                grid[i][j] = idx
                i += di
                j += dj
        return grid
    
    def __str__(self):
        """
        Get a string representing the state

        Returns
        -------
        string: A string representation of this state
        """
        s = ""
        grid = self.get_state_grid()
        for i in range(self.N):
            for j in range(self.N):
                s += "%5s"%grid[i][j]
            s += "\n"
        return s
    
    def __lt__(self, other):
        """
        Overload the less than operator so that ties can
        be broken automatically in a heap without crashing
        Parameters
        ----------
        other: State
            Another state
        
        Returns
        -------
        Result of < on string comparison of __str__ from self
        and other
        """
        return str(self) < str(other)

    def get_state_hashable(self):
        """
        Return a shorter string without line breaks that can be
        used to hash the state

        Returns
        -------
        string: A string representation of this state
        """
        s = ""
        grid = self.get_state_grid()
        for i in range(self.N):
            for j in range(self.N):
                s += "{}".format(grid[i][j])
        return s

    def plot(self):
        """
        Create a new figure and plot the state of this puzzle,
        coloring the cars by different colors
        """
        import numpy as np
        import matplotlib.pyplot as plt
        from matplotlib import cm
        from matplotlib.colors import ListedColormap
        c = cm.get_cmap("Paired", len(self.cars))
        colors = [[1, 1, 1, 1], [1, 0, 0, 1]]
        colors = colors + c.colors.tolist()
        cmap = ListedColormap(colors)
        grid = self.get_state_grid()
        grid = np.array(grid)
        plt.imshow(grid, interpolation='none', cmap=cmap)
        
    def is_goal(self):

        res = False
        car_one = self.cars[0]
        if [car_one.j+car_one.L-1] == [self.goal[1]]:
            res = True
        else:
            res = False
        return res
    
    def get_neighbors(self):
        
        neighbors = []
        for c in range(len(self.cars)):
            cloned_state = self.clone
            grid = self.get_state_grid()
            car = self.cars[c]
            if car.horiz:
                front_car = car.j + car.L
                behind_car = car.j - 1
                if front_car < self.N: 
                    if grid[car.i][front_car] == -1:
                        cloned_state = self.clone()
                        cloned_state.cars[c].j = cloned_state.cars[c].j + 1
                        neighbors.append(cloned_state)

                if behind_car >= 0:   
                    if grid[car.i][behind_car] == -1:
                        cloned_state = self.clone()
                        cloned_state.cars[c].j = cloned_state.cars[c].j - 1
                        neighbors.append(cloned_state)

            if not car.horiz:
                front_car = car.i + car.L
                behind_car = car.i - 1
                if front_car < self.N:
                    if grid[front_car][car.j] == -1: 
                        cloned_state = self.clone()
                        cloned_state.cars[c].i = cloned_state.cars[c].i + 1
                        neighbors.append(cloned_state)

                if behind_car >= 0:      
                    if grid[behind_car][car.j] == -1:
                        cloned_state = self.clone()
                        cloned_state.cars[c].i = cloned_state.cars[c].i - 1
                        neighbors.append(cloned_state)    
        
        return neighbors
    
    def solve(self):
        
        visited = set([])
        queue = [self]
        state = queue
        finished = False
        end = None
        nodes = 0
        solution = []
        # TODO: Fill this in

        while not finished and len(queue) > 0:
                state = queue.pop(0)
                if state.is_goal():
                    finished = True
                    end = state

                else:
                    neighbs = state.get_neighbors()
                    for neighbor in neighbs:
                            neighbor.prev = state
                            queue.append(neighbor)
                            nodes += 1

        print("Normal Nodes: ", nodes)
        states = [end]
        state = end                    
        while state.prev:
                
                state = state.prev
                states.append(state)
                              
        states.reverse()
        return states
        pass
    
    def solve_graph(self):
        
        visited = set([])
        queue = [self]
        state = queue
        finished = False
        end = None
        nodes = 0
        solution = []
        # TODO: Fill this in

        while not finished and len(queue) > 0:
                state = queue.pop(0)
                if state.is_goal():
                    finished = True
                    end = state

                else:
                    neighbs = state.get_neighbors()
                    for neighbor in neighbs:
                        if neighbor.get_state_hashable() not in visited:
                            neighbor.prev = state
                            queue.append(neighbor)
                            visited.add(neighbor.get_state_hashable())
                            nodes += 1

        print("BFS Nodes: ", nodes)
        states = [end]
        state = end                    
        while state.prev:
                
                state = state.prev
                states.append(state)
                              
        states.reverse()
        return states
        pass
    
    def heuristic(self):
        
        s = 0
        car_one = self.cars[0]
        front_car = car_one.j + car_one.L
        for front_car in range(self.N):
            grid = self.get_state_grid()
            if self.is_goal():
                s = 0
            if not self.is_goal():
                if grid[car_one.i][front_car] == -1:
                    s=1
                    
                else:
                    s=2
        return s           
                    
                           
    def solve_astar(self):
        
        queue = [] 
        state = self
        distance = 1
        visited = set([])
        finished = False
        end = None
        nodes = 0
        cumucost = 0      

        heappush(queue, (cumucost + self.heuristic(), state, cumucost))
         
        while not finished and len(queue) > 0:
        # Take out element from front of line
            (est, state, cumucost) = heappop(queue)
            if state.is_goal():
                finished = True
                end = state

            else:
                neighbs = state.get_neighbors()
                for neighbor in neighbs:
                    if neighbor.get_state_hashable() not in visited:

                        visited.add(neighbor.get_state_hashable())
                        neighbor.prev = state 
                        costn = cumucost + distance + neighbor.heuristic() # Moving to the neighbor costs as much as it 
                        # took to move to state, plus the cost of moving from state to neighbor,
                        # plus the heuristic
                        queue.append( (costn, neighbor, cumucost + distance) )
                        nodes += 1
                
        print("A* Nodes: ", nodes)
        states = [end]
        state = end                    
        while state.prev:
                
                state = state.prev
                states.append(state)
                              
        states.reverse()
        return states
        pass
    
    def myheuristic(self):
        
        s = 0
        car_one = self.cars[0]
        front_car = car_one.j + car_one.L
        for front_car in range(self.N):
            grid = self.get_state_grid()
            if self.is_goal():
                s = 0
            if not self.is_goal():
                if grid[car_one.i][front_car] != -1:
                    s+=1
                    
        return s    
       
        
        
    def solve_myastar(self):
                     
        queue = [] 
        state = self
        distance = 1
        visited = set([])
        finished = False
        end = None
        nodes = 0
        cumucost = 0  

        heappush(queue, (cumucost + self.myheuristic(), state, cumucost))
         
        while not finished and len(queue) > 0:
        # Take out element from front of line
            (est, state, cumucost) = heappop(queue)
            if state.is_goal():
                finished = True
                end = state

            else:
                neighbs = state.get_neighbors()
                for neighbor in neighbs:
                    if neighbor.get_state_hashable() not in visited:

                        visited.add(neighbor.get_state_hashable())
                        neighbor.prev = state
                        costn = cumucost + distance + neighbor.myheuristic() # Moving to the neighbor costs as much as it 
                        # took to move to state, plus the cost of moving from state to neighbor,
                        # plus the heuristic
                        queue.append( (costn, neighbor, cumucost + distance) )
                        nodes += 1

                    
        print("My A* Nodes: ", nodes)
        states = [end]
        state = end                    
        while state.prev:
                
                state = state.prev
                states.append(state)
                              
        states.reverse()
        return states
        pass
    
    
    
        
        
        
        
        
        
        
        
        
    